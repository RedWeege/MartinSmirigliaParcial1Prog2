package parcial1;

public class Ave extends Animal implements Rehabilitable{
    private int envargadura;
    
    public Ave(String codigo, String nombre, EstadoSalud salud, int envargadura) {
        super(codigo, nombre, salud);
        super.validarPositivo(envargadura);
        this.envargadura = envargadura;
        double mantenimiento = calcularMantenimiento();
        super.setMantenimiento(mantenimiento);
    }
    
    @Override
    public void rehabilitar() {
        System.out.println("Rehabilitada el ave codigo " + super.getCodigo() + " y nombre " + super.getNombre());
    }
    
    @Override
    protected double calcularMantenimiento() {
        return this.envargadura * 2;
    }
    
    public int getEnvargadura() {
        return this.envargadura;
    }
}
