
package parcial1;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CentroRescate {
    private String nombre;
    private List<Animal> animales;
    
    public CentroRescate(String nombre){
        Objects.requireNonNull(nombre);
        if (nombre.isBlank()){
            throw new IllegalArgumentException();
        }
        this.nombre = nombre;
        this.animales = new ArrayList<Animal>();
    }
    
    public void agregarAnimal(Animal animal) {
        Objects.requireNonNull(animal);
        verificarDuplicado(animal);
        this.animales.add(animal);
    }
    
    private void verificarDuplicado(Animal a){
        String nombreAnimalNuevo = a.getNombre();
        String codigoAnimalNuevo = a.getCodigo();
        for (int i = 0; i < this.animales.size(); i++) {
            String nombreAnimalEnCentro = this.animales.get(i).getNombre();
            String codigoAnimalEnCentro = this.animales.get(i).getCodigo();
            if (nombreAnimalNuevo == nombreAnimalEnCentro && codigoAnimalNuevo == codigoAnimalEnCentro){
                throw new IllegalArgumentException("Animal ya esta en el centro");
            }
        }
    }
    public ArrayList<Animal> obtenerAnimalesConCostoMaximo(double costo) {
        if (costo <= 0) {
            throw new IllegalArgumentException("Costo no puede ser menor o igual a 0");
        }
        ArrayList<Animal> animalesMenorACosto = new ArrayList<Animal>();
        for (int i = 0; i < this.animales.size(); i++) {
            if (this.animales.get(i).getMantenimiento() <= costo) {
                animalesMenorACosto.add(this.animales.get(i));
            }
        }
        return animalesMenorACosto;
    }
    
    public ArrayList<Animal> filtrarPorEstado(EstadoSalud estado) {
        ArrayList<Animal> animalesConEstado = new ArrayList<Animal>();
        for (int i = 0; i < this.animales.size() ; i++){
            if (this.animales.get(i).getSalud() == estado) { 
                animalesConEstado.add(this.animales.get(i));
            }
        }
        return animalesConEstado;
    }
    
    public List<Animal> obtenerAnimales(){
        return this.animales;
    }
    
    
}
