package parcial1;

public class Parcial1 {

    public static void main(String[] args) {

        Ave a1 = new Ave("B114", "Aveztruz", EstadoSalud.ESTABLE, 13);
        System.out.println(a1.getNombre());
        System.out.println(a1.getMantenimiento());
        System.out.println(a1.getCodigo());
        System.out.println(a1.getSalud());
        System.out.println(a1.getEnvargadura());
        
        Mamifero a2 = new Mamifero("B115", "Vaca", EstadoSalud.EN_RECUPERACION, 114);
        System.out.println(a2.getNombre());
        System.out.println(a2.getMantenimiento());
        System.out.println(a2.getCodigo());
        System.out.println(a2.getSalud());
        System.out.println(a2.getPeso());
        
        Reptil a3 = new Reptil("C123", "Cocodrilo", EstadoSalud.CRITICO, 18);
        System.out.println(a3.getNombre());
        System.out.println(a3.getMantenimiento());
        System.out.println(a3.getCodigo());
        System.out.println(a3.getSalud());
        System.out.println(a3.getLongitud());
        
        CentroRescate c1 = new CentroRescate("Centro Centro");
        c1.agregarAnimal(a1);
        c1.agregarAnimal(a2);
        c1.agregarAnimal(a3);
        
        System.out.println(c1.obtenerAnimales());
        System.out.println(c1.filtrarPorEstado(EstadoSalud.EN_RECUPERACION));
        System.out.println(c1.filtrarPorEstado(EstadoSalud.CRITICO));
        System.out.println(c1.filtrarPorEstado(EstadoSalud.ESTABLE));
        System.out.println(c1.obtenerAnimalesConCostoMaximo(30));
        
        a1.rehabilitar();
        a2.rehabilitar();
        a3.liberar();
        
        
    }
    
}
