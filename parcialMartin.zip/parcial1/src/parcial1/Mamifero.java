
package parcial1;

public class Mamifero extends Animal implements Rehabilitable{
    private double peso;
    
    public Mamifero(String codigo, String nombre, EstadoSalud salud, double peso) {
        super(codigo, nombre, salud);
        super.validarPositivo(peso);
        this.peso = peso;
        double mantenimiento = calcularMantenimiento();
        super.setMantenimiento(mantenimiento);
    }
    
    @Override
    protected double calcularMantenimiento() {
        return this.peso * 10;
    }
    
    @Override
    public void rehabilitar() {
        System.out.println("Rehabilitada el mamifero codigo " + super.getCodigo() + " y nombre " + super.getNombre());
    }
    
    public double getPeso() {
        return this.peso;
    }
}
