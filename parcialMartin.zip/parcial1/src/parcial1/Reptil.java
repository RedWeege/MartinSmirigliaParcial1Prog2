
package parcial1;

/**
 *
 * @author marti
 */
public class Reptil extends Animal {
    private int longitud;
    
    
    public Reptil(String codigo, String nombre, EstadoSalud salud, int longitud) {
        super(codigo, nombre, salud);
        super.validarPositivo(longitud);
        this.longitud = longitud;
        double mantenimiento = calcularMantenimiento();
        super.setMantenimiento(mantenimiento);
    }
    
    public void liberar() {
        System.out.println("El reptil codigo " + super.getCodigo() + " y nombre " + super.getNombre() + " es libre");
    }
    
    @Override
    protected double calcularMantenimiento() {
        return this.longitud + 15;
    }
    
    public int getLongitud(){
        return this.longitud;
    }
}
